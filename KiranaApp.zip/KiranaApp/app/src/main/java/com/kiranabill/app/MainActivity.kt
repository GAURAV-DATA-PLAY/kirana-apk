package com.kiranabill.app

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var sr: SpeechRecognizer? = null
    private var holding = false
    private var done = true
    private var acc = ""
    private var part = ""
    private var fails = 0
    private val h = Handler(Looper.getMainLooper())

    private val pick = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        var n = ""; var p = ""
        r.data?.data?.let { uri ->
            contentResolver.query(uri, arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER), null, null, null)?.use { c ->
                if (c.moveToFirst()) { n = c.getString(0) ?: ""; p = c.getString(1) ?: "" }
            }
        }
        js("onContact(${JSONObject.quote(n)},${JSONObject.quote(p)})")
    }

    inner class Bridge {
        @JavascriptInterface fun micStart() = runOnUiThread { startListen() }
        @JavascriptInterface fun micStop() = runOnUiThread { stopListen() }
        @JavascriptInterface fun pickContact() = runOnUiThread { pick.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI)) }
        @JavascriptInterface fun openUrl(u: String) = runOnUiThread {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (e: Exception) { toast("लिंक नहीं खुला") }
        }
        @JavascriptInterface fun sharePdf(b64: String, name: String, num: String, text: String, chooser: Boolean) =
            runOnUiThread { share(b64, name, num, text, chooser) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.parseColor("#0B7A43")
        web = WebView(this)
        setContentView(web)
        web.settings.apply { javaScriptEnabled = true; domStorageEnabled = true; allowFileAccess = false }
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? = loader.shouldInterceptRequest(request.url)
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("(window.onBack?onBack():false)") { r ->
                    if (r != "true") { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                }
            }
        })
    }

    private fun js(code: String) { web.evaluateJavascript(code, null) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ---- PDF को WhatsApp / दूसरे ऐप पर भेजना
    private fun share(b64: String, name: String, num: String, text: String, chooser: Boolean) {
        try {
            val dir = File(cacheDir, "pdf").apply { mkdirs() }
            val f = File(dir, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
            f.writeBytes(Base64.decode(b64, Base64.DEFAULT))
            val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); putExtra(Intent.EXTRA_TEXT, text)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            if (!chooser) {
                for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
                    try {
                        val w = Intent(i).setPackage(pkg)
                        if (num.isNotEmpty()) w.putExtra("jid", "$num@s.whatsapp.net")
                        startActivity(w); return
                    } catch (e: ActivityNotFoundException) {}
                }
            }
            startActivity(Intent.createChooser(i, "बिल भेजें"))
        } catch (e: Exception) { toast("शेयर नहीं हो पाया: ${e.message}") }
    }

    // ---- बोलकर लिखना: जब तक "हो गया" न दबाएं, बिना बीप के सुनता रहता है
    private val audio by lazy { getSystemService(AUDIO_SERVICE) as android.media.AudioManager }
    private fun beep(mute: Boolean) {
        for (s in intArrayOf(android.media.AudioManager.STREAM_MUSIC, android.media.AudioManager.STREAM_SYSTEM, android.media.AudioManager.STREAM_NOTIFICATION)) {
            try { audio.adjustStreamVolume(s, if (mute) android.media.AudioManager.ADJUST_MUTE else android.media.AudioManager.ADJUST_UNMUTE, 0) } catch (e: Exception) {}
        }
    }

    private fun recIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 10000L)
        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 10000L)
    }

    private val listener = object : RecognitionListener {
        override fun onPartialResults(b: Bundle?) {
            fails = 0; part = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""; push(false)
        }
        override fun onResults(b: Bundle?) {
            val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: part
            if (t.isNotBlank()) acc = (acc + " " + t).trim()
            part = ""
            if (holding) restart(60) else emit()
        }
        override fun onError(e: Int) {
            if (part.isNotBlank()) { acc = (acc + " " + part).trim(); part = "" }
            if (!holding) { emit(); return }
            when (e) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { holding = false; toast("माइक की अनुमति दें"); emit() }
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> { fails = 0; restart(60) }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> { sr?.cancel(); restart(350) }
                else -> {
                    fails++
                    if (fails > 6) { holding = false; toast("आवाज़ पहचान में दिक्कत: इंटरनेट और Google ऐप जाँचें"); emit() }
                    else restart(500)
                }
            }
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, b: Bundle?) {}
    }

    private fun startListen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
            toast("माइक की अनुमति दें, फिर दोबारा दबाकर बोलें"); js("onSpeech('',true)"); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("इस फोन में आवाज़ पहचानने की सेवा नहीं है (Google ऐप अपडेट करें)"); js("onSpeech('',true)"); return
        }
        holding = true; done = false; acc = ""; part = ""; fails = 0
        beep(true)
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this)
        sr?.setRecognitionListener(listener)
        sr?.startListening(recIntent())
    }

    private fun restart(d: Long) { h.postDelayed({ if (holding) sr?.startListening(recIntent()) }, d) }

    private fun stopListen() {
        holding = false
        sr?.stopListening()
        h.postDelayed({ emit() }, 2000)
    }

    private fun push(final: Boolean) { js("onSpeech(${JSONObject.quote((acc + " " + part).trim())},$final)") }

    private fun emit() {
        if (done) return
        done = true; beep(false); push(true); acc = ""; part = ""
    }

    override fun onStop() {
        if (holding) { holding = false; sr?.cancel(); emit() }
        super.onStop()
    }

    override fun onDestroy() { beep(false); sr?.destroy(); super.onDestroy() }
}
